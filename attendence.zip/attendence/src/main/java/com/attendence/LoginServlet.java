package com.attendence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = null;

            if ("admin".equals(role)) {

                ps = con.prepareStatement(
                        "SELECT * FROM admin WHERE username=? AND password=?");
                ps.setString(1, username);
                ps.setString(2, password);

            } else if ("teacher".equals(role)) {

                ps = con.prepareStatement(
                        "SELECT * FROM teacher WHERE email=? AND password=?");
                ps.setString(1, username);
                ps.setString(2, password);

            } else if ("student".equals(role)) {

                ps = con.prepareStatement(
                        "SELECT * FROM student WHERE email=? AND password=?");
                ps.setString(1, username);
                ps.setString(2, password);

            }

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                if ("admin".equals(role)) {

                    response.sendRedirect("admin.jsp");

                } else if ("teacher".equals(role)) {

                    response.sendRedirect("teacher.jsp");

                } else if ("student".equals(role)) {

                    response.sendRedirect("student.jsp");

                }

            } else {

                response.setContentType("text/html");

                response.getWriter().println("<html>");
                response.getWriter().println("<head><title>Login Failed</title></head>");
                response.getWriter().println("<body style='font-family:Arial;text-align:center;margin-top:100px;'>");
                response.getWriter().println("<h2 style='color:red;'>Invalid Username or Password</h2>");
                response.getWriter().println("<br>");
                response.getWriter().println("<a href='login.html'>Back to Login</a>");
                response.getWriter().println("</body>");
                response.getWriter().println("</html>");

            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType("text/html");
            response.getWriter().println("<h2>Error</h2>");
            response.getWriter().println("<pre>");
            e.printStackTrace(response.getWriter());
            response.getWriter().println("</pre>");

        }

    }

}