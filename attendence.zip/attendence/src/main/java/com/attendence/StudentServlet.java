package com.attendence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");

        String name = request.getParameter("name");
        String rollNo = request.getParameter("roll_no");
        String department = request.getParameter("department");
        String year = request.getParameter("year");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO student(name, roll_no, department, year, email, password) VALUES (?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, rollNo);
            ps.setString(3, department);
            ps.setString(4, year);
            ps.setString(5, email);
            ps.setString(6, password);

            int result = ps.executeUpdate();

            ps.close();
            con.close();

            if (result > 0) {

                response.sendRedirect("studentSuccess.jsp");

            } else {

                response.getWriter().println("<h2>Student Not Added</h2>");

            }

        }
        catch (SQLIntegrityConstraintViolationException e) {

            response.getWriter().println("<html>");
            response.getWriter().println("<head><title>Error</title></head>");
            response.getWriter().println("<body style='font-family:Arial;text-align:center;margin-top:100px;'>");
            response.getWriter().println("<h2 style='color:red;'>Roll Number Already Exists</h2>");
            response.getWriter().println("<br>");
            response.getWriter().println("<a href='student.jsp'>Go Back</a>");
            response.getWriter().println("</body>");
            response.getWriter().println("</html>");

        }
        catch (Exception e) {

            e.printStackTrace();

            response.getWriter().println("<h2>Error</h2>");
            response.getWriter().println(e.getMessage());

        }

    }
}
