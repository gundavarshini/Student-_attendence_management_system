package com.attendence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AttendanceServlet")
public class AttendanceServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String studentId = request.getParameter("studentId");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO attendance(student_id,date,status) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, Integer.parseInt(studentId));
            ps.setString(2, date);
            ps.setString(3, status);

            int result = ps.executeUpdate();

            ps.close();
            con.close();

            if(result > 0){

                response.sendRedirect("attendance.jsp?msg=success");

            }else{

                response.sendRedirect("attendance.jsp?msg=fail");

            }

        }
        catch(Exception e){

            e.printStackTrace();

            response.sendRedirect("attendance.jsp?msg=fail");

        }

    }

}