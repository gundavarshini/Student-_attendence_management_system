<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Teacher</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

body{
    background:#eef2f7;
}

/* Header */

.header{
    width:100%;
    background:linear-gradient(90deg,#1e3c72,#2a5298);
    color:white;
    text-align:center;
    padding:18px;
    font-size:28px;
    font-weight:bold;
    box-shadow:0 3px 8px rgba(0,0,0,0.2);
}

/* Form Box */

.container{
    width:420px;
    margin:50px auto;
    background:white;
    padding:30px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.2);
}

/* Labels */

label{
    display:block;
    margin-top:12px;
    margin-bottom:6px;
    font-weight:bold;
    color:#333;
}

/* Inputs */

input{
    width:100%;
    padding:12px;
    border:1px solid #ccc;
    border-radius:8px;
    font-size:15px;
    transition:0.3s;
}

input:focus{
    border-color:#2a5298;
    outline:none;
    box-shadow:0 0 8px rgba(42,82,152,0.4);
}

/* Button */

button{
    width:100%;
    margin-top:20px;
    padding:12px;
    background:#2a5298;
    color:white;
    border:none;
    border-radius:8px;
    font-size:17px;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#1e3c72;
}

/* Dashboard Link */

.back{
    display:block;
    text-align:center;
    margin-top:20px;
    text-decoration:none;
    color:#2a5298;
    font-weight:bold;
}

.back:hover{
    color:#1e3c72;
}

</style>

</head>

<body>

<div class="header">
    Add Teacher
</div>

<div class="container">

<form action="TeacherServlet" method="post">

<label>Teacher Name</label>
<input type="text" name="name" placeholder="Enter Teacher Name" required>

<label>Email</label>
<input type="email" name="email" placeholder="Enter Email" required>

<label>Subject</label>
<input type="text" name="subject" placeholder="Enter Subject" required>

<label>Password</label>
<input type="password" name="password" placeholder="Enter Password" required>

<button type="submit">Add Teacher</button>

</form>

<a href="admin.jsp" class="back">Back to Dashboard</a>

</div>

</body>
</html>