<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Student</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    margin:0;
    font-family: Arial, sans-serif;
    background:#f4f6f9;
}

/* TOP HEADER */
.header{
    background: linear-gradient(90deg, #1e3c72, #2a5298);
    color:white;
    padding:15px;
    text-align:center;
    font-size:22px;
}

/* FORM CONTAINER */
.container{
    width:400px;
    margin:40px auto;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.15);
}

/* INPUT FIELDS */
input[type="text"],
input[type="email"],
input[type="password"]{
    width:100%;
    padding:10px;
    margin:8px 0 15px 0;
    border:1px solid #ccc;
    border-radius:8px;
    transition:0.3s;
}

input:focus{
    border-color:#2a5298;
    outline:none;
    box-shadow:0 0 5px rgba(42,82,152,0.5);
}

/* BUTTON */
input[type="submit"]{
    width:100%;
    background:#2a5298;
    color:white;
    padding:12px;
    border:none;
    border-radius:8px;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}

input[type="submit"]:hover{
    background:#1e3c72;
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#2a5298;
    font-weight:bold;
}

a:hover{
    text-decoration:underline;
}

/* LABEL STYLE */
label{
    font-weight:bold;
    color:#333;
}
</style>

</head>

<body>

<div class="header">
    <i class="fa fa-user-plus"></i> Add Student
</div>

<div class="container">

<form action="StudentServlet" method="post">

<input type="text" name="name" placeholder="Student Name" required>

<input type="text" name="roll_no" placeholder="Roll Number" required>

<input type="text" name="department" placeholder="Department" required>

<input type="text" name="year" placeholder="Year" required>

<input type="email" name="email" placeholder="Email" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit">Add Student</button>

</form>