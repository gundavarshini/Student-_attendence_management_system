<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Dashboard</title>

<style>

body{
margin:0;
font-family:Arial;
background:#f4f6f9;
}

.header{
background:#1e3c72;
color:white;
padding:20px;
text-align:center;
font-size:28px;
}

.container{
width:900px;
margin:50px auto;
display:flex;
justify-content:space-around;
flex-wrap:wrap;
}

.card{
width:220px;
height:180px;
background:white;
border-radius:10px;
box-shadow:0px 0px 10px gray;
text-align:center;
padding-top:30px;
}

.card h2{
color:#1e3c72;
}

.card a{
display:inline-block;
margin-top:20px;
padding:10px 20px;
background:#2a5298;
color:white;
text-decoration:none;
border-radius:5px;
}

.card a:hover{
background:#1e3c72;
}

.logout{
text-align:center;
margin-top:40px;
}

.logout a{
background:red;
color:white;
padding:10px 25px;
text-decoration:none;
border-radius:5px;
}

</style>

</head>

<body>

<div class="header">

Student Attendance Management System

</div>

<div class="container">

<div class="card">

<h2>Teacher</h2>

<a href="teacher.jsp">Add Teacher</a>

</div>

<div class="card">

<h2>Student</h2>

<a href="student.jsp">Add Student</a>

</div>

<div class="card">

<h2>Attendance</h2>

<a href="attendance.jsp">Mark Attendance</a>

</div>

</div>

<div class="logout">

<a href="login.html">Logout</a>

</div>

</body>
</html>