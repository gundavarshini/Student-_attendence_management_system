<%@ page contentType="text/html;charset=UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Added Successfully</title>

<style>
body{
    font-family:Arial;
    background:#f4f6f9;
}

.container{
    width:450px;
    margin:120px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    text-align:center;
    box-shadow:0 0 10px gray;
}

h2{
    color:green;
}

a{
    display:inline-block;
    margin:10px;
    padding:12px 20px;
    background:#2a5298;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

a:hover{
    background:#1e3c72;
}
</style>

</head>

<body>

<div class="container">

<h2>Student Added Successfully</h2>

<a href="attendance.jsp">Mark Attendance</a>

<a href="admin.jsp">Go To Dashboard</a>

</div>

</body>
</html>