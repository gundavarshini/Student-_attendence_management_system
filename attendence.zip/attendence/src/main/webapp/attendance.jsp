<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Attendance</title>

<style>

body{
    font-family:Arial,sans-serif;
    background:#f4f4f4;
}

.container{
    width:650px;
    margin:60px auto;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 10px gray;
}

h2{
    text-align:center;
    color:#2c3e50;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}

th,td{
    border:1px solid #ddd;
    padding:10px;
    text-align:center;
}

th{
    background:#007bff;
    color:white;
}

input,select{
    width:100%;
    padding:8px;
    box-sizing:border-box;
}

input[type=submit]{
    width:100%;
    margin-top:20px;
    padding:12px;
    background:green;
    color:white;
    border:none;
    cursor:pointer;
    font-size:16px;
}

input[type=submit]:hover{
    background:darkgreen;
}

.success{
    background:#d4edda;
    color:#155724;
    border:1px solid #c3e6cb;
    padding:12px;
    margin-bottom:20px;
    text-align:center;
    font-weight:bold;
    border-radius:5px;
}

.error{
    background:#f8d7da;
    color:#721c24;
    border:1px solid #f5c6cb;
    padding:12px;
    margin-bottom:20px;
    text-align:center;
    font-weight:bold;
    border-radius:5px;
}

</style>

</head>

<body>

<div class="container">

<h2>Student Attendance</h2>

<%
String msg=request.getParameter("msg");

if("success".equals(msg)){
%>

<div class="success">
Attendance Marked Successfully
</div>

<%
}
else if("fail".equals(msg)){
%>

<div class="error">
Attendance Not Saved
</div>

<%
}
%>

<form action="AttendanceServlet" method="post">

<table>

<tr>
<th>Attendance ID</th>
<th>Student ID</th>
<th>Date</th>
<th>Status</th>
</tr>

<tr>

<td>
<input type="text" value="Auto Generated" readonly>
</td>

<td>
<input type="number" name="studentId" required>
</td>

<td>
<input type="date" name="date" required>
</td>

<td>

<select name="status">

<option value="Present">Present</option>

<option value="Absent">Absent</option>

</select>

</td>

</tr>

</table>

<input type="submit" value="Mark Attendance">

</form>

</div>

</body>
</html>