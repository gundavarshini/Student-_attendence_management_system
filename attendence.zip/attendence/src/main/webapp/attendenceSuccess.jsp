<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Attendance Success</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
}

.box{

    width:450px;
    margin:120px auto;
    background:white;
    padding:30px;
    text-align:center;
    border-radius:10px;
    box-shadow:0 0 10px gray;

}

h2{

    color:green;

}

a{

    display:inline-block;
    padding:12px 25px;
    margin:10px;
    background:#2a5298;
    color:white;
    text-decoration:none;
    border-radius:5px;

}

a:hover{

    background:#1d3d73;

}

</style>

</head>

<body>

<div class="box">

<h2>Attendance Marked Successfully</h2>

<a href="attendance.jsp">Mark Another Attendance</a>

<a href="admin.jsp">Go To Dashboard</a>

</div>

</body>
</html>